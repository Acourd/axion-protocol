'use strict';

const assert = require('assert');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const {
  APPROVAL_STATUS,
  computePublicKeyId,
  createSignedApproval,
  verifyAndConsumeApproval,
} = require('../../tools/approval_ed25519.js');
const {
  CHECK_STATUS,
  createSignedCheck,
  verifyIndependentCheck,
} = require('../../tools/check_ed25519.js');
const { hashCanonical } = require('../../tools/canonical_json.js');

const ROOT = path.join(__dirname, '..', '..');
const FIXTURE_ROOT = path.join(
  ROOT,
  '.phase-e',
  'test-runtime',
  `role-sep-${process.pid}-${Date.now()}`,
);
fs.mkdirSync(FIXTURE_ROOT, { recursive: true });

// --- Helper: create an isolated fixture with 3 actors ---

function createThreeActorFixture(label, opts = {}) {
  const dir = path.join(FIXTURE_ROOT, `${label}-${crypto.randomBytes(4).toString('hex')}`);
  fs.mkdirSync(dir, { recursive: true });
  const consumptionDir = path.join(dir, 'consumed');
  fs.mkdirSync(consumptionDir, { recursive: false });

  const executorId = opts.executorId || 'executor-actor';
  const approverId = opts.approverId || 'approver-actor';
  const auditorId = opts.auditorId || 'auditor-actor';

  const approverKeys = opts.approverKeys || crypto.generateKeyPairSync('ed25519');
  const auditorKeys = opts.auditorKeys || crypto.generateKeyPairSync('ed25519');
  const approverKeyId = computePublicKeyId(approverKeys.publicKey);
  const auditorKeyId = computePublicKeyId(auditorKeys.publicKey);

  const authorities = [
    {
      keyId: approverKeyId,
      actorId: approverId,
      roles: opts.approverRoles || ['HUMAN_AUTHORITY'],
      status: 'TRUSTED',
      expiresAt: '2099-01-01T00:00:00.000Z',
      publicKeyPem: approverKeys.publicKey.export({ type: 'spki', format: 'pem' }),
    },
  ];

  // Only add auditor entry if actorId differs or keyId differs from approver.
  // When approver === auditor identity, we need a second registry entry with
  // the auditor role to allow the same actor to sign both.
  if (auditorId !== approverId || opts.forceSeparateAuditorEntry) {
    authorities.push({
      keyId: auditorKeyId,
      actorId: auditorId,
      roles: opts.auditorRoles || ['INDEPENDENT_AUDITOR'],
      status: 'TRUSTED',
      expiresAt: '2099-01-01T00:00:00.000Z',
      publicKeyPem: auditorKeys.publicKey.export({ type: 'spki', format: 'pem' }),
    });
  } else {
    // Same actor, add INDEPENDENT_AUDITOR role to existing entry
    authorities[0].roles = [...new Set([...authorities[0].roles, 'INDEPENDENT_AUDITOR'])];
    // Use auditor keys for the combined entry if they differ
    if (auditorKeyId !== approverKeyId) {
      authorities.push({
        keyId: auditorKeyId,
        actorId: auditorId,
        roles: ['INDEPENDENT_AUDITOR'],
        status: 'TRUSTED',
        expiresAt: '2099-01-01T00:00:00.000Z',
        publicKeyPem: auditorKeys.publicKey.export({ type: 'spki', format: 'pem' }),
      });
    }
  }

  const registryPath = path.join(dir, 'trusted-authorities.json');
  fs.writeFileSync(registryPath, JSON.stringify({
    version: '1.0.0',
    authorities,
  }, null, 2), 'utf8');

  const missionId = `AX-ROLE-SEP-${crypto.randomBytes(4).toString('hex')}`;
  const command = { executable: 'node', args: ['--version'], cwd: ROOT, shell: false };
  const scope = ['tools/approval_ed25519.js'];
  const risk = 'HIGH';
  const policySource = fs.readFileSync(path.join(ROOT, 'policies', 'risk.yaml'), 'utf8');
  const { compileRiskPolicy } = require('../../tools/risk_policy_compiler.js');
  const compiledPolicy = compileRiskPolicy(policySource);
  const requirementsHash = hashCanonical(compiledPolicy.levels.HIGH.requirements);
  const policyHash = crypto.createHash('sha256').update(policySource, 'utf8').digest('hex');
  const rollbackPlan = {
    contractVersion: '1.0.0',
    planId: `RB-SEP-${crypto.randomBytes(4).toString('hex')}`,
    missionId,
    strategy: 'RESTORE_SNAPSHOT',
    snapshotDigest: 'a'.repeat(64),
    steps: ['restore from immutable snapshot'],
    verification: ['compare SHA-256 manifest'],
  };
  const rollbackHash = hashCanonical(rollbackPlan);

  const binding = {
    contractVersion: '1.0.0',
    missionId,
    risk,
    command,
    scope,
    requirementsHash,
    policyHash,
    rollbackHash,
  };

  return {
    dir,
    registryPath,
    consumptionDir,
    executorId,
    approverId,
    auditorId,
    approverKeys,
    auditorKeys,
    approverKeyId,
    auditorKeyId,
    missionId,
    command,
    scope,
    risk,
    binding,
    rollbackPlan,
    rollbackHash,
    requirementsHash,
    policyHash,
  };
}

function createApprovalEnvelope(fixture, overrides = {}) {
  const unsigned = {
    contractVersion: fixture.binding.contractVersion,
    approvalId: `AX-APR-${crypto.randomBytes(8).toString('hex')}`,
    missionId: fixture.missionId,
    actorId: overrides.actorId || fixture.approverId,
    keyId: overrides.keyId || fixture.approverKeyId,
    decision: 'APPROVE',
    risk: fixture.risk,
    command: fixture.command,
    scope: fixture.scope,
    requirementsHash: fixture.requirementsHash,
    policyHash: fixture.policyHash,
    rollbackHash: fixture.rollbackHash,
    issuedAt: new Date(Date.now() - 60_000).toISOString(),
    expiresAt: new Date(Date.now() + 600_000).toISOString(),
    nonce: crypto.randomBytes(32).toString('base64url'),
    usageLimit: 1,
  };
  const key = overrides.privateKey || fixture.approverKeys.privateKey;
  return createSignedApproval(unsigned, key);
}

function createCheckEnvelope(fixture, approvalDigest, overrides = {}) {
  const unsigned = {
    contractVersion: '1.0.0',
    checkId: `AX-CHK-${crypto.randomBytes(8).toString('hex')}`,
    missionId: fixture.missionId,
    actorId: overrides.actorId || fixture.auditorId,
    keyId: overrides.keyId || fixture.auditorKeyId,
    executorActorId: overrides.executorActorId || fixture.executorId,
    risk: fixture.risk,
    commandHash: hashCanonical(fixture.command),
    approvalDigest,
    assertionsHash: hashCanonical(['role-separation-test']),
    result: 'PASS',
    exitCode: 0,
    evidenceHash: hashCanonical({ fixture: 'role-separation-evidence' }),
    issuedAt: new Date(Date.now() - 30_000).toISOString(),
    expiresAt: new Date(Date.now() + 600_000).toISOString(),
  };
  const key = overrides.privateKey || fixture.auditorKeys.privateKey;
  return createSignedCheck(unsigned, key);
}

// ============================================================================
// RED TESTS — These demonstrate existing vulnerabilities (F-01, F-02)
// Expected behavior BEFORE patch:
//   - Tests 1, 3, 4, 9: Should FAIL (defect confirmed — vulnerability exists)
//   - Tests 2, 5: Should PASS (already enforced or correct behavior)
//   - Tests 6, 7, 8: Should PASS (absent identities already blocked)
//   - Test 10: Should FAIL (nonce consumed despite self-approval)
// ============================================================================

let passed = 0;
let failed = 0;
let invalidTests = 0;

function expectStatus(testNum, desc, actual, expected, isRedTest) {
  if (actual === expected) {
    console.log(`  [${testNum}] PASS: ${desc} — got ${actual}`);
    passed++;
  } else if (isRedTest) {
    // Red tests: EXPECTED to fail before patch (vulnerability demonstration)
    console.log(`  [${testNum}] RED_CONFIRMED: ${desc} — got ${actual}, want ${expected} (vulnerability demonstrated)`);
    failed++;
  } else {
    console.log(`  [${testNum}] UNEXPECTED_FAIL: ${desc} — got ${actual}, want ${expected}`);
    invalidTests++;
  }
}

console.log('=== ROLE SEPARATION RED TESTS (pre-patch) ===\n');

// --- Test 1: executor === approver → should block with APPROVAL_NOT_INDEPENDENT ---
// F-01 vulnerability: verifyAndConsumeApproval does not compare against executorActorId
{
  const fixture = createThreeActorFixture('t1-self-approval', {
    executorId: 'alice',
    approverId: 'alice',
    auditorId: 'bob',
    forceSeparateAuditorEntry: true,
  });

  const approvalEnvelope = createApprovalEnvelope(fixture);
  const approvalResult = verifyAndConsumeApproval({
    envelope: approvalEnvelope,
    expectedBinding: fixture.binding,
    registryPath: fixture.registryPath,
    consumptionDir: fixture.consumptionDir,
    executorActorId: fixture.executorId,
    now: new Date(),
  });

  // Before patch: returns APPROVAL_VALID (vulnerability F-01)
  // After patch: should return APPROVAL_NOT_INDEPENDENT
  expectStatus(1, 'executor=approver blocked at approval', approvalResult.status,
    'APPROVAL_NOT_INDEPENDENT', true);
}

// --- Test 2: executor === auditor → should block with CHECK_NOT_INDEPENDENT ---
// Already enforced in check_ed25519.js:110
{
  const fixture = createThreeActorFixture('t2-executor-auditor', {
    executorId: 'alice',
    approverId: 'bob',
    auditorId: 'alice',
    forceSeparateAuditorEntry: true,
  });

  const approvalEnvelope = createApprovalEnvelope(fixture);
  const approvalDigest = hashCanonical(approvalEnvelope.approval);
  const checkEnvelope = createCheckEnvelope(fixture, approvalDigest);
  const checkResult = verifyIndependentCheck({
    envelope: checkEnvelope,
    expectedBinding: {
      missionId: fixture.missionId,
      risk: fixture.risk,
      commandHash: hashCanonical(fixture.command),
      approvalDigest,
      assertionsHash: hashCanonical(['role-separation-test']),
    },
    registryPath: fixture.registryPath,
    executorActorId: fixture.executorId,
    approvalActorId: fixture.approverId,
    now: new Date(),
  });

  expectStatus(2, 'executor=auditor blocked at CHECK', checkResult.status,
    CHECK_STATUS.CHECK_NOT_INDEPENDENT, false);
}

// --- Test 3: approver === auditor → should block with CHECK_NOT_INDEPENDENT ---
// F-02 vulnerability: verifyIndependentCheck does not compare against approvalActorId
{
  const sameKeys = crypto.generateKeyPairSync('ed25519');
  const auditorKeys = crypto.generateKeyPairSync('ed25519');
  const fixture = createThreeActorFixture('t3-approver-auditor', {
    executorId: 'charlie',
    approverId: 'alice',
    auditorId: 'alice',
    approverKeys: sameKeys,
    auditorKeys: auditorKeys,
    forceSeparateAuditorEntry: true,
  });

  const approvalEnvelope = createApprovalEnvelope(fixture);
  const approvalDigest = hashCanonical(approvalEnvelope.approval);
  const checkEnvelope = createCheckEnvelope(fixture, approvalDigest);
  const checkResult = verifyIndependentCheck({
    envelope: checkEnvelope,
    expectedBinding: {
      missionId: fixture.missionId,
      risk: fixture.risk,
      commandHash: hashCanonical(fixture.command),
      approvalDigest,
      assertionsHash: hashCanonical(['role-separation-test']),
    },
    registryPath: fixture.registryPath,
    executorActorId: fixture.executorId,
    approvalActorId: fixture.approverId,
    now: new Date(),
  });

  // Before patch: returns CHECK_VALID (vulnerability F-02)
  // After patch: should return CHECK_NOT_INDEPENDENT
  expectStatus(3, 'approver=auditor blocked at CHECK', checkResult.status,
    CHECK_STATUS.CHECK_NOT_INDEPENDENT, true);
}

// --- Test 4: executor === approver === auditor → should block ---
{
  const aliceApproverKeys = crypto.generateKeyPairSync('ed25519');
  const aliceAuditorKeys = crypto.generateKeyPairSync('ed25519');
  const fixture = createThreeActorFixture('t4-all-same', {
    executorId: 'alice',
    approverId: 'alice',
    auditorId: 'alice',
    approverKeys: aliceApproverKeys,
    auditorKeys: aliceAuditorKeys,
    forceSeparateAuditorEntry: true,
  });

  const approvalEnvelope = createApprovalEnvelope(fixture);
  const approvalResult = verifyAndConsumeApproval({
    envelope: approvalEnvelope,
    expectedBinding: fixture.binding,
    registryPath: fixture.registryPath,
    consumptionDir: fixture.consumptionDir,
    executorActorId: fixture.executorId,
    now: new Date(),
  });

  // Before patch: APPROVAL_VALID (F-01 vulnerability)
  // After patch: APPROVAL_NOT_INDEPENDENT
  expectStatus(4, 'all-same blocked at approval', approvalResult.status,
    'APPROVAL_NOT_INDEPENDENT', true);
}

// --- Test 5: three distinct actors → should succeed ---
{
  const fixture = createThreeActorFixture('t5-all-distinct', {
    executorId: 'charlie',
    approverId: 'alice',
    auditorId: 'bob',
    forceSeparateAuditorEntry: true,
  });

  const approvalEnvelope = createApprovalEnvelope(fixture);
  const approvalResult = verifyAndConsumeApproval({
    envelope: approvalEnvelope,
    expectedBinding: fixture.binding,
    registryPath: fixture.registryPath,
    consumptionDir: fixture.consumptionDir,
    executorActorId: fixture.executorId,
    now: new Date(),
  });
  assert.strictEqual(approvalResult.status, APPROVAL_STATUS.APPROVAL_VALID,
    `Test 5 approval should pass, got: ${approvalResult.status}`);

  const approvalDigest = hashCanonical(approvalEnvelope.approval);
  const checkEnvelope = createCheckEnvelope(fixture, approvalDigest);
  const checkResult = verifyIndependentCheck({
    envelope: checkEnvelope,
    expectedBinding: {
      missionId: fixture.missionId,
      risk: fixture.risk,
      commandHash: hashCanonical(fixture.command),
      approvalDigest,
      assertionsHash: hashCanonical(['role-separation-test']),
    },
    registryPath: fixture.registryPath,
    executorActorId: fixture.executorId,
    approvalActorId: fixture.approverId,
    now: new Date(),
  });

  expectStatus(5, 'three distinct actors pass', checkResult.status,
    CHECK_STATUS.CHECK_VALID, false);
}

// --- Test 6: executorActorId absent → should block ---
{
  const fixture = createThreeActorFixture('t6-no-executor', {
    executorId: 'charlie',
    approverId: 'alice',
    auditorId: 'bob',
    forceSeparateAuditorEntry: true,
  });

  const approvalEnvelope = createApprovalEnvelope(fixture);
  const approvalDigest = hashCanonical(approvalEnvelope.approval);
  const checkEnvelope = createCheckEnvelope(fixture, approvalDigest);
  const checkResult = verifyIndependentCheck({
    envelope: checkEnvelope,
    expectedBinding: {
      missionId: fixture.missionId,
      risk: fixture.risk,
      commandHash: hashCanonical(fixture.command),
      approvalDigest,
      assertionsHash: hashCanonical(['role-separation-test']),
    },
    registryPath: fixture.registryPath,
    executorActorId: undefined,
    approvalActorId: fixture.approverId,
    now: new Date(),
  });

  expectStatus(6, 'absent executorActorId blocked', checkResult.status,
    CHECK_STATUS.CHECK_NOT_INDEPENDENT, false);
}

// --- Test 7: approvalActorId absent (no approval envelope) → should block ---
{
  const fixture = createThreeActorFixture('t7-no-approval', {
    executorId: 'charlie',
    approverId: 'alice',
    auditorId: 'bob',
    forceSeparateAuditorEntry: true,
  });

  const approvalResult = verifyAndConsumeApproval({
    envelope: undefined,
    expectedBinding: fixture.binding,
    registryPath: fixture.registryPath,
    consumptionDir: fixture.consumptionDir,
    executorActorId: fixture.executorId,
    now: new Date(),
  });

  expectStatus(7, 'absent approval blocked', approvalResult.status,
    APPROVAL_STATUS.APPROVAL_MISSING, false);
}

// --- Test 8: auditorActorId absent (no check envelope) → should block ---
{
  const fixture = createThreeActorFixture('t8-no-check', {
    executorId: 'charlie',
    approverId: 'alice',
    auditorId: 'bob',
    forceSeparateAuditorEntry: true,
  });

  const checkResult = verifyIndependentCheck({
    envelope: undefined,
    expectedBinding: {
      missionId: fixture.missionId,
      risk: fixture.risk,
      commandHash: hashCanonical(fixture.command),
      approvalDigest: 'a'.repeat(64),
      assertionsHash: hashCanonical(['role-separation-test']),
    },
    registryPath: fixture.registryPath,
    executorActorId: fixture.executorId,
    approvalActorId: fixture.approverId,
    now: new Date(),
  });

  expectStatus(8, 'absent check blocked', checkResult.status,
    CHECK_STATUS.CHECK_MISSING, false);
}

// --- Test 9: dual-role actor (HUMAN_AUTHORITY + INDEPENDENT_AUDITOR) approves and audits ---
// F-02 vulnerability: same identity with both roles can approve and audit
{
  const dualApproverKeys = crypto.generateKeyPairSync('ed25519');
  const dualAuditorKeys = crypto.generateKeyPairSync('ed25519');
  const dualApproverKeyId = computePublicKeyId(dualApproverKeys.publicKey);
  const dualAuditorKeyId = computePublicKeyId(dualAuditorKeys.publicKey);

  const dir = path.join(FIXTURE_ROOT, `t9-dual-role-${crypto.randomBytes(4).toString('hex')}`);
  fs.mkdirSync(dir, { recursive: true });
  const consumptionDir = path.join(dir, 'consumed');
  fs.mkdirSync(consumptionDir);
  const registryPath = path.join(dir, 'trusted-authorities.json');

  // alice has two keys: one for HUMAN_AUTHORITY, one for INDEPENDENT_AUDITOR
  fs.writeFileSync(registryPath, JSON.stringify({
    version: '1.0.0',
    authorities: [
      {
        keyId: dualApproverKeyId,
        actorId: 'alice-dual',
        roles: ['HUMAN_AUTHORITY'],
        status: 'TRUSTED',
        expiresAt: '2099-01-01T00:00:00.000Z',
        publicKeyPem: dualApproverKeys.publicKey.export({ type: 'spki', format: 'pem' }),
      },
      {
        keyId: dualAuditorKeyId,
        actorId: 'alice-dual',
        roles: ['INDEPENDENT_AUDITOR'],
        status: 'TRUSTED',
        expiresAt: '2099-01-01T00:00:00.000Z',
        publicKeyPem: dualAuditorKeys.publicKey.export({ type: 'spki', format: 'pem' }),
      },
    ],
  }, null, 2), 'utf8');

  const missionId = `AX-DUAL-${crypto.randomBytes(4).toString('hex')}`;
  const command = { executable: 'node', args: ['--version'], cwd: ROOT, shell: false };
  const scope = ['tools/approval_ed25519.js'];
  const policySource = fs.readFileSync(path.join(ROOT, 'policies', 'risk.yaml'), 'utf8');
  const { compileRiskPolicy } = require('../../tools/risk_policy_compiler.js');
  const compiledPolicy = compileRiskPolicy(policySource);
  const requirementsHash = hashCanonical(compiledPolicy.levels.HIGH.requirements);
  const policyHash = crypto.createHash('sha256').update(policySource, 'utf8').digest('hex');
  const rollbackPlan = {
    contractVersion: '1.0.0',
    planId: `RB-DUAL-${crypto.randomBytes(4).toString('hex')}`,
    missionId,
    strategy: 'RESTORE_SNAPSHOT',
    snapshotDigest: 'a'.repeat(64),
    steps: ['restore from immutable snapshot'],
    verification: ['compare SHA-256 manifest'],
  };
  const rollbackHash = hashCanonical(rollbackPlan);

  const binding = {
    contractVersion: '1.0.0',
    missionId,
    risk: 'HIGH',
    command,
    scope,
    requirementsHash,
    policyHash,
    rollbackHash,
  };

  // alice approves as HUMAN_AUTHORITY
  const unsignedApproval = {
    contractVersion: '1.0.0',
    approvalId: `AX-APR-DUAL-${crypto.randomBytes(8).toString('hex')}`,
    missionId,
    actorId: 'alice-dual',
    keyId: dualApproverKeyId,
    decision: 'APPROVE',
    risk: 'HIGH',
    command,
    scope,
    requirementsHash,
    policyHash,
    rollbackHash,
    issuedAt: new Date(Date.now() - 60_000).toISOString(),
    expiresAt: new Date(Date.now() + 600_000).toISOString(),
    nonce: crypto.randomBytes(32).toString('base64url'),
    usageLimit: 1,
  };
  const approvalEnvelope = createSignedApproval(unsignedApproval, dualApproverKeys.privateKey);
  const approvalDigest = hashCanonical(unsignedApproval);

  // alice audits as INDEPENDENT_AUDITOR using her second key
  const unsignedCheck = {
    contractVersion: '1.0.0',
    checkId: `AX-CHK-DUAL-${crypto.randomBytes(8).toString('hex')}`,
    missionId,
    actorId: 'alice-dual',
    keyId: dualAuditorKeyId,
    executorActorId: 'executor-other',
    risk: 'HIGH',
    commandHash: hashCanonical(command),
    approvalDigest,
    assertionsHash: hashCanonical(['role-separation-test']),
    result: 'PASS',
    exitCode: 0,
    evidenceHash: hashCanonical({ fixture: 'dual-role-evidence' }),
    issuedAt: new Date(Date.now() - 30_000).toISOString(),
    expiresAt: new Date(Date.now() + 600_000).toISOString(),
  };
  const checkEnvelope = createSignedCheck(unsignedCheck, dualAuditorKeys.privateKey);

  const checkResult = verifyIndependentCheck({
    envelope: checkEnvelope,
    expectedBinding: {
      missionId,
      risk: 'HIGH',
      commandHash: hashCanonical(command),
      approvalDigest,
      assertionsHash: hashCanonical(['role-separation-test']),
    },
    registryPath,
    executorActorId: 'executor-other',
    approvalActorId: 'alice-dual',
    now: new Date(),
  });

  // Before patch: CHECK_VALID (F-02 vulnerability — no approver vs auditor comparison)
  // After patch: CHECK_NOT_INDEPENDENT
  expectStatus(9, 'dual-role actor blocked at CHECK', checkResult.status,
    CHECK_STATUS.CHECK_NOT_INDEPENDENT, true);
}

// --- Test 10: self-approval rejection must NOT consume nonce ---
// F-01 vulnerability: currently no rejection happens, so nonce IS consumed
{
  const fixture = createThreeActorFixture('t10-nonce-safe', {
    executorId: 'alice',
    approverId: 'alice',
    auditorId: 'bob',
    forceSeparateAuditorEntry: true,
  });

  // Count consumed files before
  const filesBefore = fs.readdirSync(fixture.consumptionDir).length;

  const approvalEnvelope = createApprovalEnvelope(fixture);
  const approvalResult = verifyAndConsumeApproval({
    envelope: approvalEnvelope,
    expectedBinding: fixture.binding,
    registryPath: fixture.registryPath,
    consumptionDir: fixture.consumptionDir,
    executorActorId: fixture.executorId,
    now: new Date(),
  });

  const filesAfter = fs.readdirSync(fixture.consumptionDir).length;

  // Before patch: nonce IS consumed (APPROVAL_VALID, file created)
  // After patch: nonce should NOT be consumed (APPROVAL_NOT_INDEPENDENT, no file)
  if (approvalResult.status === 'APPROVAL_NOT_INDEPENDENT' && filesAfter === filesBefore) {
    console.log('  [10] PASS: self-approval rejected without consuming nonce');
    passed++;
  } else if (approvalResult.status === APPROVAL_STATUS.APPROVAL_VALID) {
    // Vulnerability confirmed: nonce consumed for a self-approval
    console.log(`  [10] RED_CONFIRMED: self-approval accepted and nonce consumed (${filesAfter - filesBefore} files created)`);
    failed++;
  } else {
    console.log(`  [10] UNEXPECTED: status=${approvalResult.status}, files_before=${filesBefore}, files_after=${filesAfter}`);
    invalidTests++;
  }
}

// ============================================================================
// SUMMARY
// ============================================================================

console.log('\n=== SUMMARY ===');
console.log(`Total: 10`);
console.log(`Already passing (green): ${passed}`);
console.log(`Vulnerability demonstrated (red): ${failed}`);
console.log(`Invalid tests: ${invalidTests}`);

if (invalidTests > 0) {
  console.log('\nSTATUS: INVALID_TEST — A test expected to demonstrate a vulnerability already passes.');
  process.exit(2);
}

if (failed > 0) {
  console.log(`\nSTATUS: RED_TESTS_VALID — ${failed} vulnerabilities confirmed, ready for patch.`);
  process.exit(0);
} else {
  console.log('\nSTATUS: ALL_PASS — All tests pass; patch may already be applied or tests are incorrect.');
  process.exit(0);
}

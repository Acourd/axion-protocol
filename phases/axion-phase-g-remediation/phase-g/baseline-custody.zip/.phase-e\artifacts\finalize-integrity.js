'use strict';

const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..', '..');
const artifacts = __dirname;
const baselineRoot = path.join(artifacts, 'baseline-snapshot');
const changeSetRoot = path.join(artifacts, 'final-change-set');
const rollbackRoot = path.join(artifacts, 'final-rollback-lab');
const reapplyRoot = path.join(artifacts, 'final-reapply-lab');
const excludedTopLevel = new Set(['.phase-e', 'scratch']);

for (const target of [changeSetRoot, rollbackRoot, reapplyRoot]) {
  if (fs.existsSync(target)) throw new Error(`El laboratorio ya existe: ${target}`);
}

function digest(buffer) {
  return crypto.createHash('sha256').update(buffer).digest('hex');
}

function encodingOf(buffer) {
  if (buffer.length >= 3 && buffer[0] === 0xef && buffer[1] === 0xbb && buffer[2] === 0xbf) return 'UTF-8_BOM';
  if (buffer.length >= 2 && buffer[0] === 0xff && buffer[1] === 0xfe) return 'UTF-16LE_BOM';
  if (buffer.every((byte) => byte < 0x80)) return 'ASCII_COMPATIBLE';
  const decoded = buffer.toString('utf8');
  return Buffer.from(decoded, 'utf8').equals(buffer) ? 'UTF-8_NO_BOM' : 'BINARY_OR_OTHER';
}

function lineEndingsOf(buffer) {
  if (buffer.includes(0)) return 'BINARY_OR_NONE';
  const text = buffer.toString('utf8');
  const crlf = (text.match(/\r\n/g) || []).length;
  const lf = (text.replace(/\r\n/g, '').match(/\n/g) || []).length;
  const cr = (text.replace(/\r\n/g, '').match(/\r/g) || []).length;
  if (crlf && !lf && !cr) return 'CRLF';
  if (lf && !crlf && !cr) return 'LF';
  if (!crlf && !lf && !cr) return 'NONE';
  return 'MIXED';
}

function scan(scanRoot, exclusions = new Set()) {
  const files = [];
  const directories = [];
  function visit(relativeDir) {
    const absoluteDir = path.join(scanRoot, relativeDir);
    const entries = fs.readdirSync(absoluteDir, { withFileTypes: true })
      .sort((a, b) => a.name.localeCompare(b.name));
    for (const entry of entries) {
      if (!relativeDir && exclusions.has(entry.name)) continue;
      const relative = path.join(relativeDir, entry.name).split(path.sep).join('/');
      const absolute = path.join(scanRoot, relativeDir, entry.name);
      const stat = fs.statSync(absolute);
      if (entry.isDirectory()) {
        directories.push({ path: relative, mode: stat.mode });
        visit(path.join(relativeDir, entry.name));
      } else if (entry.isFile()) {
        const bytes = fs.readFileSync(absolute);
        files.push({
          path: relative,
          size_bytes: bytes.length,
          sha256: digest(bytes),
          mode: stat.mode,
          encoding: encodingOf(bytes),
          line_endings: lineEndingsOf(bytes),
        });
      }
    }
  }
  visit('');
  return { files, directories };
}

function mapFiles(manifest) {
  return new Map(manifest.files.map((entry) => [entry.path, entry]));
}

function compare(expected, actual) {
  const expectedMap = mapFiles(expected);
  const actualMap = mapFiles(actual);
  const missing = [];
  const extra = [];
  const divergent = [];
  for (const [relative, entry] of expectedMap) {
    const other = actualMap.get(relative);
    if (!other) missing.push(relative);
    else if (entry.sha256 !== other.sha256 || entry.mode !== other.mode
        || entry.encoding !== other.encoding || entry.line_endings !== other.line_endings) {
      divergent.push(relative);
    }
  }
  for (const relative of actualMap.keys()) if (!expectedMap.has(relative)) extra.push(relative);
  const expectedDirs = new Set(expected.directories.map((entry) => entry.path));
  const actualDirs = new Set(actual.directories.map((entry) => entry.path));
  const missingDirectories = [...expectedDirs].filter((entry) => !actualDirs.has(entry));
  const extraDirectories = [...actualDirs].filter((entry) => !expectedDirs.has(entry));
  return { missing, extra, divergent, missingDirectories, extraDirectories };
}

function copyRelative(sourceRoot, targetRoot, relative) {
  const source = path.join(sourceRoot, ...relative.split('/'));
  const target = path.join(targetRoot, ...relative.split('/'));
  fs.mkdirSync(path.dirname(target), { recursive: true });
  fs.copyFileSync(source, target);
  fs.chmodSync(target, fs.statSync(source).mode);
}

const baseline = scan(baselineRoot);
const current = scan(root, excludedTopLevel);
const baselineMap = mapFiles(baseline);
const currentMap = mapFiles(current);
const added = current.files.filter((entry) => !baselineMap.has(entry.path)).map((entry) => entry.path);
const deleted = baseline.files.filter((entry) => !currentMap.has(entry.path)).map((entry) => entry.path);
const modified = current.files.filter((entry) => {
  const prior = baselineMap.get(entry.path);
  return prior && prior.sha256 !== entry.sha256;
}).map((entry) => entry.path);
const unchanged = current.files.length - added.length - modified.length;
if (deleted.length > 0) throw new Error(`La reaplicacion no borra rutas; se detectaron ${deleted.length} eliminaciones.`);

fs.mkdirSync(changeSetRoot, { recursive: false });
for (const relative of [...modified, ...added]) copyRelative(root, changeSetRoot, relative);

fs.cpSync(baselineRoot, rollbackRoot, { recursive: true, preserveTimestamps: true });
const rollbackComparison = compare(baseline, scan(rollbackRoot));

fs.cpSync(baselineRoot, reapplyRoot, { recursive: true, preserveTimestamps: true });
for (const relative of [...modified, ...added]) copyRelative(changeSetRoot, reapplyRoot, relative);
const reapplyComparison = compare(current, scan(reapplyRoot));

const clean = (comparison) => Object.values(comparison).every((entries) => entries.length === 0);
const productManifest = {
  schema: 'AXION_PHASE_E_FINAL_PRODUCT_MANIFEST_V1',
  source_commit: 'ef229b4a4914dad7596fabbce7375baaa56518c6',
  excluded_generated_roots: [...excludedTopLevel],
  file_count: current.files.length,
  directory_count: current.directories.length,
  content_preservation: 'BYTE_EXACT',
  mode_semantics: 'NODE_STAT_MODE_ON_WINDOWS',
  files: current.files,
  directories: current.directories,
};
const changeManifest = {
  schema: 'AXION_PHASE_E_CHANGE_SET_V1',
  baseline_files: baseline.files.length,
  final_files: current.files.length,
  modified,
  added,
  deleted,
  unchanged,
  change_set_files: modified.length + added.length,
};
const report = {
  schema: 'AXION_PHASE_E_ROLLBACK_REAPPLY_V1',
  baseline_files: baseline.files.length,
  rollback: { pass: clean(rollbackComparison), comparison: rollbackComparison },
  reapply: { pass: clean(reapplyComparison), comparison: reapplyComparison },
  compared_properties: ['path', 'sha256', 'mode', 'encoding', 'line_endings'],
  generated_residue_excluded: ['.phase-e', 'scratch'],
};

for (const [name, value] of [
  ['final-product-manifest.json', productManifest],
  ['final-change-manifest.json', changeManifest],
  ['rollback-reapply-report.json', report],
]) {
  const serialized = `${JSON.stringify(value, null, 2)}\n`;
  fs.writeFileSync(path.join(artifacts, name), serialized, 'utf8');
  fs.writeFileSync(path.join(artifacts, `${name}.sha256`), `${digest(Buffer.from(serialized, 'utf8'))}  ${name}\n`, 'ascii');
}

console.log(JSON.stringify({
  baselineFiles: baseline.files.length,
  finalFiles: current.files.length,
  modified: modified.length,
  added: added.length,
  deleted: deleted.length,
  rollbackPass: report.rollback.pass,
  reapplyPass: report.reapply.pass,
}, null, 2));

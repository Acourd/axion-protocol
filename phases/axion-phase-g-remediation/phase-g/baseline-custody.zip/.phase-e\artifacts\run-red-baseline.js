'use strict';

const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');

const artifacts = __dirname;
const baseline = path.join(artifacts, 'baseline-snapshot');
const lab = path.join(artifacts, 'final-red-baseline-lab');
if (fs.existsSync(lab)) throw new Error(`El laboratorio ya existe: ${lab}`);
fs.cpSync(baseline, lab, { recursive: true, preserveTimestamps: true });
const targetTests = path.join(lab, 'tests', 'phase_e');
fs.mkdirSync(targetTests, { recursive: true });

const probes = [
  'approval_forgery_baseline.test.js',
  'c01_governance_chain.test.js',
  'c02_destructive_classifier.test.js',
  'c03_independent_attestations.test.js',
];
const results = [];
for (const probe of probes) {
  fs.copyFileSync(path.join(path.resolve(artifacts, '..', '..'), 'tests', 'phase_e', probe), path.join(targetTests, probe));
  const execution = spawnSync(process.execPath, [path.join(targetTests, probe)], {
    cwd: lab,
    shell: false,
    encoding: 'utf8',
    maxBuffer: 1024 * 1024,
  });
  const lines = `${execution.stdout || ''}\n${execution.stderr || ''}`
    .split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
  results.push({
    probe,
    red: execution.status !== 0,
    exit_code: execution.status,
    defect_evidence: lines.find((line) => /AssertionError|PASS inesperado|VERIFIED/.test(line)) || lines.at(-1) || '',
  });
}

const report = {
  schema: 'AXION_PHASE_E_RED_BASELINE_REPORT_V1',
  baseline_files: 73,
  destructive_commands_executed: false,
  probes,
  red_count: results.filter((entry) => entry.red).length,
  results,
};
const serialized = `${JSON.stringify(report, null, 2)}\n`;
const reportPath = path.join(artifacts, 'final-red-baseline-report.json');
fs.writeFileSync(reportPath, serialized, 'utf8');
const digest = crypto.createHash('sha256').update(serialized, 'utf8').digest('hex');
fs.writeFileSync(`${reportPath}.sha256`, `${digest}  final-red-baseline-report.json\n`, 'ascii');
console.log(JSON.stringify({ red: `${report.red_count}/${probes.length}`, sha256: digest }, null, 2));
if (report.red_count !== probes.length) process.exit(1);

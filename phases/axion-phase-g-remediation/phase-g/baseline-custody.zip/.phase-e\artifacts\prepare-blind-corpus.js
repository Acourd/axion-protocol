'use strict';

const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');

const sourceRoot = path.resolve(__dirname, '..', '..');
const deliveryRoot = 'C:\\Users\\Ayco\\Shoshin\\axion-phase-f-delivery';
const stagingParent = path.join(__dirname, 'blind-corpus-staging');
const corpusRoot = path.join(stagingParent, 'axion-enforcement-blind-corpus');
const validationRoot = path.join(__dirname, 'blind-corpus-validation-lab');

for (const target of [deliveryRoot, stagingParent, validationRoot]) {
  if (fs.existsSync(target)) throw new Error(`El destino ya existe; no se sobrescribe: ${target}`);
}
fs.mkdirSync(deliveryRoot, { recursive: false });
fs.mkdirSync(corpusRoot, { recursive: true });

const excludedRoots = new Set(['.phase-e', 'scratch']);
const excludedRelativeFiles = new Set([
  'phase-e-integrity.yaml',
  'phase-e-inventory.yaml',
  'sha256-manifest.txt',
  'docs/lineage.md',
]);
const pathRenames = new Map([
  ['tests/phase_e/approval_forgery_baseline.test.js', 'tests/runtime_security/approval_input_validation.test.js'],
  ['tests/phase_e/c01_governance_chain.test.js', 'tests/runtime_security/critical_workflow_boundaries.test.js'],
  ['tests/phase_e/c02_destructive_classifier.test.js', 'tests/runtime_security/command_classification_matrix.test.js'],
  ['tests/phase_e/c03_independent_attestations.test.js', 'tests/runtime_security/attestation_provenance.test.js'],
  ['tests/regression/ax_f_001_installer_backup.test.js', 'tests/regression/installer_backup_preservation.test.js'],
  ['tests/regression/ax_f_002_risk_gate.test.js', 'tests/regression/risk_gate_normalization.test.js'],
  ['tests/regression/ax_f_003_verified_requires_checks.test.js', 'tests/regression/independent_check_requirement.test.js'],
  ['tests/regression/ax_f_004_evidence_manifest.test.js', 'tests/regression/evidence_manifest_completeness.test.js'],
  ['tests/regression/ax_f_005_preflight_destructive.test.js', 'tests/regression/destructive_command_matrix.test.js'],
  ['tests/regression/ax_f_006_learnings_preservation.test.js', 'tests/regression/learning_history_preservation.test.js'],
  ['tests/regression/ax_f_008_doc_consistency.test.js', 'tests/regression/documentation_consistency.test.js'],
  ['tests/regression/ax_f_012_suite_integrity.test.js', 'tests/regression/test_suite_integrity.test.js'],
]);

const textualExtensions = new Set(['.js', '.md', '.yaml', '.yml', '.json', '.html', '.css', '.txt']);
const codeLabels = new Map([
  ['AX-F-001', 'installer backup preservation'],
  ['AX-F-002', 'risk gate normalization'],
  ['AX-F-003', 'independent CHECK requirement'],
  ['AX-F-004', 'evidence manifest completeness'],
  ['AX-F-005', 'destructive command matrix'],
  ['AX-F-006', 'learning history preservation'],
  ['AX-F-008', 'documentation consistency'],
  ['AX-F-012', 'test suite integrity'],
]);

function neutralize(relative, buffer) {
  if (!textualExtensions.has(path.extname(relative).toLowerCase())) return buffer;
  let text = buffer.toString('utf8');
  text = text
    .replace(/\.phase-e/gi, '.runtime-fixtures')
    .replace(/tests\/phase_e/gi, 'tests/runtime_security')
    .replace(/phase_e/gi, 'runtime_security')
    .replace(/phase-e/gi, 'runtime-security')
    .replace(/\bFase E\b/gi, 'enforcement actual')
    .replace(/\bPhase E\b/gi, 'current enforcement')
    .replace(/READY_FOR_REAUDIT/gi, 'REVIEW_PENDING')
    .replace(/840d36d3[a-f0-9]*/gi, 'reference-redacted')
    .replace(/b12d33d1[a-f0-9]*/gi, 'reference-redacted')
    .replace(/C-01/g, 'critical workflow boundary')
    .replace(/C-02/g, 'command classification matrix')
    .replace(/C-03/g, 'attestation provenance');
  for (const [label, replacement] of codeLabels) text = text.split(label).join(replacement);
  text = text
    .replace(/Regresi[oó]n\s+(installer backup preservation|risk gate normalization|independent CHECK requirement|evidence manifest completeness|destructive command matrix|learning history preservation|documentation consistency|test suite integrity)\s+[—-]\s+/gi, 'Prueba: ')
    .replace(/Fijan el comportamiento exigido por las pol[ií]ticas del proyecto tras la auditor[ií]a\s+independiente del 2026-08-03\. Cada archivo corresponde a un hallazgo `AX-F-\*` y fue\s+verificado en rojo antes de su parche y en verde despu[eé]s\./gi,
      'Fijan propiedades funcionales y de seguridad exigidas por las politicas del proyecto. Los nombres describen el comportamiento comprobado sin incorporar procedencia historica.')
    .replace(/PASS approval forgery/gi, 'PASS approval input validation');
  return Buffer.from(text, 'utf8');
}

const copied = [];
const excluded = [];
const neutralized = [];

function visit(relativeDir = '') {
  const absoluteDir = path.join(sourceRoot, relativeDir);
  const entries = fs.readdirSync(absoluteDir, { withFileTypes: true }).sort((a, b) => a.name.localeCompare(b.name));
  for (const entry of entries) {
    if (!relativeDir && excludedRoots.has(entry.name)) {
      excluded.push(entry.name);
      continue;
    }
    const sourceRelative = path.join(relativeDir, entry.name).split(path.sep).join('/');
    if (excludedRelativeFiles.has(sourceRelative)
        || /\.axion-backup-/i.test(sourceRelative)
        || /axion-informe|audit-report|auditoria-ciega/i.test(sourceRelative)
        || /\.(zip|sha256)$/i.test(sourceRelative)) {
      excluded.push(sourceRelative);
      continue;
    }
    const absolute = path.join(sourceRoot, ...sourceRelative.split('/'));
    if (entry.isDirectory()) {
      visit(sourceRelative);
      continue;
    }
    if (!entry.isFile()) continue;
    let targetRelative = pathRenames.get(sourceRelative) || sourceRelative.replace(/^tests\/phase_e\//, 'tests/runtime_security/');
    const target = path.join(corpusRoot, ...targetRelative.split('/'));
    fs.mkdirSync(path.dirname(target), { recursive: true });
    const original = fs.readFileSync(absolute);
    const output = neutralize(sourceRelative, original);
    fs.writeFileSync(target, output);
    fs.chmodSync(target, fs.statSync(absolute).mode);
    copied.push(targetRelative);
    if (!output.equals(original) || targetRelative !== sourceRelative) neutralized.push({ source: sourceRelative, target: targetRelative });
  }
}
visit();

fs.cpSync(corpusRoot, validationRoot, { recursive: true, preserveTimestamps: true });
function testsUnder(directory) {
  const results = [];
  for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
    const absolute = path.join(directory, entry.name);
    if (entry.isDirectory()) results.push(...testsUnder(absolute));
    else if (entry.isFile() && entry.name.endsWith('.test.js')) results.push(absolute);
  }
  return results.sort();
}
const tests = testsUnder(path.join(validationRoot, 'tests'));
const testResults = tests.map((test) => {
  const run = spawnSync(process.execPath, [test], {
    cwd: validationRoot,
    shell: false,
    encoding: 'utf8',
    maxBuffer: 4 * 1024 * 1024,
  });
  return {
    test: path.relative(validationRoot, test).split(path.sep).join('/'),
    exit_code: run.status,
    pass: run.status === 0,
  };
});

const forbidden = /C-01|C-02|C-03|Phase E|Fase E|phase_e|phase-e|READY_FOR_REAUDIT|840d36d3|b12d33d1/i;
const forbiddenHits = [];
for (const relative of copied) {
  const absolute = path.join(corpusRoot, ...relative.split('/'));
  if (forbidden.test(relative)) forbiddenHits.push({ path: relative, location: 'path' });
  if (textualExtensions.has(path.extname(relative).toLowerCase())) {
    const text = fs.readFileSync(absolute, 'utf8');
    if (forbidden.test(text)) forbiddenHits.push({ path: relative, location: 'content' });
  }
}
const privateKeyHits = copied.filter((relative) => {
  const bytes = fs.readFileSync(path.join(corpusRoot, ...relative.split('/')));
  return /BEGIN (RSA |EC |OPENSSH |)PRIVATE KEY/.test(bytes.toString('utf8'));
});
const historicalNames = copied.filter((relative) => /ax_f_|c0[123]|phase/i.test(relative));
const report = {
  schema: 'AXION_BLIND_CORPUS_PREPARATION_V1',
  source_files: copied.length,
  excluded,
  neutralized,
  forbidden_hits: forbiddenHits,
  historical_name_hits: historicalNames,
  private_key_pem_hits: privateKeyHits,
  tests: {
    total: testResults.length,
    passed: testResults.filter((entry) => entry.pass).length,
    failed: testResults.filter((entry) => !entry.pass).length,
    results: testResults,
  },
};
const serialized = `${JSON.stringify(report, null, 2)}\n`;
fs.writeFileSync(path.join(__dirname, 'blind-corpus-validation.json'), serialized, 'utf8');
fs.writeFileSync(
  path.join(__dirname, 'blind-corpus-validation.json.sha256'),
  `${crypto.createHash('sha256').update(serialized, 'utf8').digest('hex')}  blind-corpus-validation.json\n`,
  'ascii',
);

console.log(JSON.stringify({
  corpusRoot,
  deliveryRoot,
  files: copied.length,
  neutralized: neutralized.length,
  excluded: excluded.length,
  tests: `${report.tests.passed}/${report.tests.total}`,
  forbiddenHits: forbiddenHits.length,
  historicalNameHits: historicalNames.length,
  privateKeyPemHits: privateKeyHits.length,
}, null, 2));
if (report.tests.failed || forbiddenHits.length || historicalNames.length || privateKeyHits.length) process.exit(1);

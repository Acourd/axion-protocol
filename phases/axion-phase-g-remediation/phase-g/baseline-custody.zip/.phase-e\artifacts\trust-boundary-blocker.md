# AXION Fase E — bloqueo de raíz de confianza

## Punto de detención

Orden autorizado: **aprobación verificable**, inmediatamente después de la compilación de
requisitos de riesgo.

## Evidencia

El runtime actual comparte proceso, usuario y sistema de archivos con el ejecutor. No existe:

- registro de autoridades protegido;
- clave pública o certificado aprobado;
- proceso o servicio de aprobación independiente;
- identidad del sistema operativo vinculada a un rol de Axion;
- canal externo autenticado;
- repositorio/remoto que funcione como ancla inmutable de decisiones.

Por ello, cualquiera de estas alternativas sería falsificable por el propio ejecutor y viola
las condiciones de Fase E:

- JSON local con `approved_by`;
- callback que retorna `true`;
- nombre de actor o rol declarado en el payload;
- hash calculado y entregado por el mismo payload;
- HMAC con secreto embebido o compartido en el corpus;
- capability o `Symbol` creado dentro del mismo proceso sin provisionamiento externo.

## Clasificación

`BLOCKED_TRUST_ROOT_REQUIRED`

Resolverlo exige una decisión humana de arquitectura y una raíz de confianza externa al payload.
Si se eligiera firma asimétrica, servicio de aprobación, nueva dependencia o infraestructura, la
condición 12 ordena detenerse antes de implementarlo. Hasta entonces, HIGH/CRITICAL solo pueden
fallar cerrado y `VERIFIED` no puede acreditarse como independiente.

No se implementaron aprobación, CHECK, máquina de estados, comando estructurado, binding,
evidencia ni rollback de producto después de detectar este bloqueo.

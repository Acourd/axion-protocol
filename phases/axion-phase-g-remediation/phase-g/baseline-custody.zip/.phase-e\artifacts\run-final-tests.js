'use strict';

const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');

const root = path.resolve(__dirname, '..', '..');
const phaseEDir = path.join(root, 'tests', 'phase_e');

function collect(directory, recursive) {
  const output = [];
  for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
    const absolute = path.join(directory, entry.name);
    if (entry.isDirectory() && recursive && absolute !== phaseEDir) output.push(...collect(absolute, true));
    if (entry.isFile() && entry.name.endsWith('.test.js')) output.push(absolute);
  }
  return output;
}

const legacy = collect(path.join(root, 'tests'), true)
  .filter((file) => !file.startsWith(`${phaseEDir}${path.sep}`))
  .sort();
const phaseE = collect(phaseEDir, false).sort();

function run(file) {
  const result = spawnSync(process.execPath, [file], {
    cwd: root,
    shell: false,
    encoding: 'utf8',
    maxBuffer: 4 * 1024 * 1024,
  });
  const lines = `${result.stdout || ''}\n${result.stderr || ''}`
    .split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
  return {
    test: path.relative(root, file).split(path.sep).join('/'),
    exit_code: Number.isInteger(result.status) ? result.status : null,
    pass: result.status === 0,
    final_line: lines.at(-1) || '',
  };
}

const legacyResults = legacy.map(run);
const phaseEResults = phaseE.map(run);
const report = {
  schema: 'AXION_PHASE_E_TEST_REPORT_V1',
  destructive_commands_executed: false,
  execution_model: 'each test executed by Node with shell:false',
  legacy: {
    total: legacyResults.length,
    passed: legacyResults.filter((entry) => entry.pass).length,
    failed: legacyResults.filter((entry) => !entry.pass).length,
    results: legacyResults,
  },
  phase_e: {
    total: phaseEResults.length,
    passed: phaseEResults.filter((entry) => entry.pass).length,
    failed: phaseEResults.filter((entry) => !entry.pass).length,
    results: phaseEResults,
  },
};
const serialized = `${JSON.stringify(report, null, 2)}\n`;
const output = path.join(__dirname, 'final-test-report.json');
fs.writeFileSync(output, serialized, 'utf8');
const digest = crypto.createHash('sha256').update(serialized, 'utf8').digest('hex');
fs.writeFileSync(`${output}.sha256`, `${digest}  final-test-report.json\n`, 'ascii');
console.log(JSON.stringify({
  legacy: `${report.legacy.passed}/${report.legacy.total}`,
  phaseE: `${report.phase_e.passed}/${report.phase_e.total}`,
  failed: report.legacy.failed + report.phase_e.failed,
  sha256: digest,
}, null, 2));
if (report.legacy.failed || report.phase_e.failed) process.exit(1);
